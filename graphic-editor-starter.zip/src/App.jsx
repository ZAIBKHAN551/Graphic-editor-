import React, { useRef, useState } from 'react'
import { Stage, Layer, Image as KonvaImage, Text as KonvaText, Transformer } from 'react-konva'

function URLImage({ image, isSelected, onSelect, onChange }) {
  const shapeRef = useRef()
  const trRef = useRef()

  React.useEffect(() => {
    if (isSelected) {
      trRef.current.nodes([shapeRef.current])
      trRef.current.getLayer().batchDraw()
    }
  }, [isSelected])

  return (
    <>
      <KonvaImage
        image={image}
        x={50}
        y={50}
        draggable
        ref={shapeRef}
        onClick={onSelect}
        onTap={onSelect}
        onDragEnd={e => {
          onChange({
            ...image._meta,
            x: e.target.x(),
            y: e.target.y(),
          })
        }}
        onTransformEnd={e => {
          const node = shapeRef.current
          const scaleX = node.scaleX()
          const scaleY = node.scaleY()
          node.scaleX(1)
          node.scaleY(1)
          onChange({
            ...image._meta,
            x: node.x(),
            y: node.y(),
            width: Math.max(5, node.width() * scaleX),
            height: Math.max(node.height() * scaleY)
          })
        }}
      />
      {isSelected && <Transformer ref={trRef} />}
    </>
  )
}

function useImage(url) {
  const [img, setImg] = React.useState(null)
  React.useEffect(() => {
    if (!url) return
    const image = new window.Image()
    image.crossOrigin = 'anonymous'
    image.src = url
    image.onload = () => setImg(image)
  }, [url])
  return img
}

export default function App() {
  const stageRef = useRef()
  const [images, setImages] = useState([])
  const [selectedId, setSelectedId] = useState(null)
  const [texts, setTexts] = useState([])
  const [textVal, setTextVal] = useState('Your text here')
  const [bgColor, setBgColor] = useState('#ffffff')

  const handleUpload = (file) => {
    const reader = new FileReader()
    reader.onload = () => {
      const src = reader.result
      const img = new window.Image()
      img.src = src
      img.crossOrigin = 'anonymous'
      img.onload = () => {
        const meta = { x: 50, y: 50, width: img.width, height: img.height, id: Date.now() }
        img._meta = meta
        setImages(prev => [...prev, img])
      }
    }
    reader.readAsDataURL(file)
  }

  const exportPNG = () => {
    const uri = stageRef.current.toDataURL({ pixelRatio: 1 })
    const link = document.createElement('a')
    link.download = 'design.png'
    link.href = uri
    document.body.appendChild(link)
    link.click()
    link.remove()
  }

  const addText = () => {
    const id = Date.now()
    setTexts(prev => [...prev, { id, text: textVal, x: 100, y: 100, fontSize: 30 }])
  }
  const updateText = (id, attrs) => {
    setTexts(prev => prev.map(t => t.id === id ? { ...t, ...attrs } : t))
  }

  const selectedImage = images.find(img => img._meta.id === selectedId)

  return (
    <div className="app">
      <div className="sidebar">
        <h3>Graphic Editor Starter</h3>
        <div className="controls">
          <input type="file" accept="image/*" onChange={e => e.target.files[0] && handleUpload(e.target.files[0])} />
          <button onClick={addText}>Add Text</button>
          <input value={textVal} onChange={e=>setTextVal(e.target.value)} placeholder="Text to add" />
          <input type="color" value={bgColor} onChange={e=>setBgColor(e.target.value)} />
          <button onClick={exportPNG}>Export PNG</button>
          <hr/>
          <div>
            <h4>Layers</h4>
            {images.map(img => <div key={img._meta.id} style={{padding:6, borderBottom:'1px solid #eee'}} onClick={()=>setSelectedId(img._meta.id)}>{img._meta.id}</div>)}
            {texts.map(t => <div key={t.id} style={{padding:6, borderBottom:'1px solid #eee'}} onClick={()=>setSelectedId(t.id)}>{t.text.slice(0,20)}</div>)}
          </div>
        </div>
      </div>

      <div className="canvasWrap">
        <div className="canvasContainer">
          <Stage width={900} height={600} ref={stageRef} style={{background:bgColor}}>
            <Layer>
              {images.map(img => (
                <URLImage key={img._meta.id} image={img} isSelected={selectedId===img._meta.id}
                  onSelect={()=>setSelectedId(img._meta.id)}
                  onChange={(meta)=> {
                    img._meta = meta
                    setImages(prev => prev.map(i => i._meta.id===img._meta.id? img : i))
                  }}
                />
              ))}
              {texts.map(t => (
                <KonvaText key={t.id}
                  text={t.text}
                  x={t.x}
                  y={t.y}
                  fontSize={t.fontSize}
                  draggable
                  onDragEnd={e=> updateText(t.id, { x: e.target.x(), y: e.target.y() })}
                  onDblClick={()=>{
                    const newVal = prompt('Edit text', t.text)
                    if(newVal!==null) updateText(t.id, { text: newVal })
                  }}
                />
              ))}
            </Layer>
          </Stage>
        </div>
      </div>
    </div>
  )
}
