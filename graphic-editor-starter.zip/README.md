# Graphic Editor Starter

This is a minimal Vite + React + Konva starter project.
Features:
- Image upload
- Drag / resize / rotate images
- Add & edit text
- Export PNG

## How to run locally

1. Install Node.js (v16+)
2. Open terminal:
```
npm install
npm run dev
```
3. Open http://localhost:5173

## Deploy to GitHub + Vercel
1. Create a GitHub repo and push this project.
2. Connect the repo to Vercel and deploy (Vercel will auto-detect Vite/React).
